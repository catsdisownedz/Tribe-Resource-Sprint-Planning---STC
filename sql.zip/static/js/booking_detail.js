// static/js/booking_detail.js
(function () {
  // Grab the 6 sprint checkboxes (they must have data-sprint="1..6")
  const boxes = Array.from(document.querySelectorAll('input[type="checkbox"][data-sprint]'));
  if (!boxes.length) return;

  const bookBtn   = document.getElementById('btn-book');
  const counterEl = document.getElementById('reservedCounter'); // optional <span id="reservedCounter"></span>

  // Globals injected by booking_detail.html
  const BOOKED = Array.isArray(window.BOOKED_SPRINTS) ? window.BOOKED_SPRINTS.map(Number) : [];
  const TEMP_ID = Number(window.TEMP_ID ?? 0);
  const RESERVED_LIMIT = Number(window.RESERVED_LIMIT ?? 0);

  // Treat 0 as “no cap” so UX isn’t blocked if there’s no limit configured
  const CAP = RESERVED_LIMIT > 0 ? RESERVED_LIMIT : 6;

  const bookedSet = new Set(BOOKED);

  function selectedCount() {
    return boxes.filter(b => b.checked).length;
  }

  function setDisabled(box, shouldDisable, reason = '') {
    box.disabled = !!shouldDisable;
    const label = box.closest('label') || box.parentElement;
    if (label) {
      if (shouldDisable) {
        label.classList.add('opacity-50');
        if (reason) label.title = reason;
      } else {
        label.classList.remove('opacity-50');
        label.removeAttribute('title');
      }
    }
  }

  // 1) Block previously booked sprints immediately
  boxes.forEach(box => {
    const sprint = Number(box.getAttribute('data-sprint'));
    if (bookedSet.has(sprint)) {
      setDisabled(box, true, 'Already booked');
    }
  });

  // 2) Live enforce reserved cap
  function refreshCap() {
    const count = selectedCount();
    if (counterEl) counterEl.textContent = `${count} / ${CAP}${RESERVED_LIMIT === 0 ? ' (no cap)' : ''}`;

    // If under cap, enable all *unbooked* checkboxes; if at cap, disable remaining
    boxes.forEach(box => {
      const sprint = Number(box.getAttribute('data-sprint'));
      if (bookedSet.has(sprint)) {
        // stays disabled forever
        return;
      }
      if (count >= CAP && !box.checked) {
        setDisabled(box, true, 'Reached reserved limit');
      } else {
        setDisabled(box, false);
      }
    });
  }

  boxes.forEach(b => b.addEventListener('change', refreshCap));
  refreshCap();

  // 3) Book button logic
  if (bookBtn) {
    bookBtn.addEventListener('click', async () => {
      const chosen = boxes
        .filter(b => b.checked)
        .map(b => Number(b.getAttribute('data-sprint')));

      if (chosen.length === 0) {
        alert('Pick at least one sprint');
        return;
      }

      try {
        const res = await fetch(`/api/book-temp/${TEMP_ID}`, {
          method: 'POST',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({ sprints: chosen })
        });

        if (!res.ok) {
          const data = await res.json().catch(() => ({}));
          const msg = data?.error || data?.details?.join('\n') || `Booking failed (${res.status})`;
          alert(msg);
          return;
        }

        const data = await res.json().catch(() => ({}));
        // Optional success message from backend:
        if (data?.message) {
          // You can show a toast/snackbar instead of alert if you like.
          // alert(data.message);
        }
        // Redirect to home after success
        window.location.href = '/';
      } catch (e) {
        console.error(e);
        alert('Network error while booking');
      }
    });
  }
})();
