// static/js/booking.js - list and selection of temp assignments
(function(){
  // ---- DOM ----
  const els = {
    tribe:    document.getElementById('bTribe'),
    type:     document.getElementById('bType'),
    app:      document.getElementById('bApp'),
    resource: document.getElementById('bResource'),
    role:     document.getElementById('bRole'),
    tableBody:document.getElementById('tempBody'),
    ok:       document.getElementById('selectOk')
  };
  if (!els.tableBody) return; // not on this page

  // ---- local cache + fetch dedupe ----
  let cache = [];                // last loaded rows
  let lastQuery = '';            // last querystring we fetched
  let inflight = null;           // dedupe promise
  const TTL_MS = 15000;          // 15s stale-while-revalidate
  let lastFetchAt = 0;

  function qsFromFilters(){
    const p = new URLSearchParams();
    if (els.tribe.value.trim())    p.set('tribe',    els.tribe.value.trim());
    if (els.type.value.trim())     p.set('type',     els.type.value.trim());
    if (els.app.value.trim())      p.set('app',      els.app.value.trim());
    if (els.resource.value.trim()) p.set('resource', els.resource.value.trim());
    if (els.role.value.trim())     p.set('role',     els.role.value.trim());
    return p.toString();
  }

  async function fetchList(force=false){
    const now = Date.now();
    const q = qsFromFilters();
    const url = q ? `/api/temp-assignments?${q}` : `/api/temp-assignments`;

    // serve from cache if still fresh and query unchanged
    if (!force && q === lastQuery && (now - lastFetchAt) < TTL_MS && cache.length){
      return cache;
    }

    // in-flight request dedupe
    if (inflight) return inflight;

    inflight = fetch(url, { credentials: 'same-origin' })
      .then(async r => {
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        return r.json();
      })
      .then(rows => {
        cache = Array.isArray(rows) ? rows : [];
        lastQuery = q;
        lastFetchAt = Date.now();
        return cache;
      })
      .finally(() => { inflight = null; });

    return inflight;
  }

  // ---- render ----
  function render(rows){
    // EXPECTED ROW SHAPE: { id, resource_name, role, tribe, type, app, assign_type, ... }
    // If your columns differ, adjust the <td> mapping below.
    const html = rows.map(r => `
      <tr data-id="${r.id}">
        <td>${r.resource_name ?? ''}</td>
        <td>${r.role ?? ''}</td>
        <td>${r.tribe ?? ''}</td>
        <td>${r.type ?? ''}</td>
        <td>${r.app ?? ''}</td>
        <td>${r.assign_type ?? ''}</td>
      </tr>
    `).join('');
    els.tableBody.innerHTML = html;
  }

  function filterLocal(){
    // simple client-side filter against cached array
    const tribe    = els.tribe.value.trim().toLowerCase();
    const type     = els.type.value.trim().toLowerCase();
    const app      = els.app.value.trim().toLowerCase();
    const resource = els.resource.value.trim().toLowerCase();
    const role     = els.role.value.trim().toLowerCase();

    const filtered = cache.filter(r => (
      (!tribe    || String(r.tribe).toLowerCase().includes(tribe)) &&
      (!type     || String(r.type).toLowerCase().includes(type)) &&
      (!app      || String(r.app).toLowerCase().includes(app)) &&
      (!resource || String(r.resource_name).toLowerCase().includes(resource)) &&
      (!role     || String(r.role).toLowerCase().includes(role))
    ));
    render(filtered);
  }

  // ---- debounce on every keypress ----
  function debounce(fn, ms){ let t; return (...a)=>{ clearTimeout(t); t=setTimeout(()=>fn(...a), ms); }; }
  const onInput = debounce(() => {
    filterLocal();                  // instant UX on cached data
    // gentle background refresh that never spams the API
    fetchList(/*force*/ true).then(() => filterLocal()).catch(()=>{});
  }, 150);

  ['input','change'].forEach(evt => {
    [els.tribe, els.type, els.app, els.resource, els.role].forEach(el => {
      if (el) el.addEventListener(evt, onInput);
    });
  });

  // ---- single-shot init on first tab show or immediate if visible ----
  let initialized = false;
  function initOnce(){
    if (initialized) return;
    initialized = true;
    fetchList(/*force*/ true).then(() => filterLocal()).catch(()=>{});
  }

  const tabBtn = document.querySelector('[data-bs-target="#booking-tab"], #booking-tab-btn, a[href="#booking"]');
  if (tabBtn) {
    tabBtn.addEventListener('shown.bs.tab', initOnce, { once: true });
    tabBtn.addEventListener('click', initOnce, { once: true });
  }
  // also init if content is already visible (avoids the “switch 2–3 times” bug)
  if (document.getElementById('booking')?.offsetParent !== null || !tabBtn) {
    initOnce();
  }

  // “OK/Select” keeps current filtered choice logic untouched
  if (els.ok) {
    els.ok.addEventListener('click', () => {
      const tr = els.tableBody.querySelector('tr.table-active');
      if (!tr) return;
      const id = tr.getAttribute('data-id');
      window.location.href = `/booking/${id}`;
    });
  }

  // keep table row selection behavior
  els.tableBody.addEventListener('click', (e) => {
    const tr = e.target.closest('tr');
    if (!tr) return;
    els.tableBody.querySelectorAll('tr').forEach(r => r.classList.remove('table-active'));
    tr.classList.add('table-active');
  });
})();// static/js/booking.js — render Temp Assignments in the Booking tab (simple & fast)
(function(){
  // ----- Cache DOM -----
  const els = {
    tribe:     document.getElementById('bTribe'),
    type:      document.getElementById('bType'),
    app:       document.getElementById('bApp'),
    resource:  document.getElementById('bResource'),
    role:      document.getElementById('bRole'),
    tableBody: document.getElementById('tempBody'),
    ok:        document.getElementById('selectOk')
  };
  if (!els.tableBody) return; // not on this page

  // ----- Small helpers -----
  const debounce = (fn, ms=250) => {
    let t = null;
    return (...args) => {
      clearTimeout(t);
      t = setTimeout(() => fn(...args), ms);
    };
  };

  const buildQuery = () => {
    const p = new URLSearchParams();
    if (els.tribe?.value.trim())    p.set('tribe', els.tribe.value.trim());
    if (els.type?.value.trim())     p.set('type', els.type.value.trim());
    if (els.app?.value.trim())      p.set('app', els.app.value.trim());
    if (els.resource?.value.trim()) p.set('resource', els.resource.value.trim());
    if (els.role?.value.trim())     p.set('role', els.role.value.trim());
    return p.toString();
  };

  const setLoading = (isLoading) => {
    if (isLoading) {
      els.tableBody.innerHTML = `<tr><td colspan="7" class="text-center py-3">Loading…</td></tr>`;
    }
  };

  const renderRows = (items=[]) => {
    if (!Array.isArray(items) || items.length === 0) {
      els.tableBody.innerHTML = `<tr><td colspan="7" class="text-center py-3 text-muted">No matching rows</td></tr>`;
      els.ok?.setAttribute('disabled', 'true');
      return;
    }

    const rowsHtml = items.map(r => {
      const reserved = Number(r.reserved ?? r.reserved_sprints ?? 0);
      return `
        <tr data-id="${r.temp_id}">
          <td>${r.tribe ?? r.tribe_name ?? ''}</td>
          <td>${r.type ?? r.assign_type ?? ''}</td>
          <td>${r.app ?? r.app_name ?? ''}</td>
          <td>${r.resource_name ?? ''}</td>
          <td>${r.role ?? ''}</td>
          <td class="text-center">${reserved}</td>
          <td class="text-end">
            <button class="btn btn-sm btn-outline-primary act-select">Select</button>
          </td>
        </tr>
      `;
    }).join('');
    els.tableBody.innerHTML = rowsHtml;
    els.ok?.setAttribute('disabled', 'true'); // reset until a row is chosen
  };

  // ----- Load function (public) -----
  async function load({source} = {}) {
    setLoading(true);
    const q = buildQuery();
    const url = q ? `/api/temp-assignments?${q}` : `/api/temp-assignments`;
    try {
      const resp = await fetch(url);
      const text = await resp.text();
      if (!resp.ok) throw new Error(text);
      const json = JSON.parse(text);
      renderRows(json.items || []);
    } catch (err) {
      els.tableBody.innerHTML = `<tr><td colspan="7" class="text-danger py-3">Failed to load: ${String(err).slice(0,200)}</td></tr>`;
    }
  }

  // expose to other scripts (main.js calls this on tab show)
  window.loadTempAssignments = load;

  // ----- Events -----
  const onFilterInput = debounce(() => load({source: 'filter'}), 300);
  [els.tribe, els.type, els.app, els.resource, els.role].forEach(el => {
    el?.addEventListener('input', onFilterInput);
  });

  // row click → select
  els.tableBody.addEventListener('click', (e) => {
    const tr = e.target.closest('tr');
    if (!tr) return;

    // button click navigates immediately
    if (e.target.classList.contains('act-select')) {
      const id = tr.getAttribute('data-id');
      if (id) window.location.href = `/booking/${id}`;
      return;
    }

    // otherwise just mark selection
    els.tableBody.querySelectorAll('tr').forEach(r => r.classList.remove('table-active'));
    tr.classList.add('table-active');
    els.ok?.removeAttribute('disabled');
  });

  // double click row → navigate
  els.tableBody.addEventListener('dblclick', (e) => {
    const tr = e.target.closest('tr');
    if (!tr) return;
    const id = tr.getAttribute('data-id');
    if (id) window.location.href = `/booking/${id}`;
  });

  // OK button
  els.ok?.addEventListener('click', () => {
    const tr = els.tableBody.querySelector('tr.table-active');
    if (!tr) return;
    const id = tr.getAttribute('data-id');
    if (id) window.location.href = `/booking/${id}`;
  });

  // ----- Initial load (so the first tab shows data immediately) -----
  // This ensures you DON'T need to switch tabs 2–3 times.
  load({source: 'dom-ready'});
})();

